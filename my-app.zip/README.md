## Run instructions

1. Run `npm install`
2. Run `ng serve`
